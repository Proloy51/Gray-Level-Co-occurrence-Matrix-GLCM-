How to run:

1. Place your image.
2. Update displacement in main.py line 11
3. Run main.py


## Notice

All the GLCM steps are saved inside the sims folder. Write them on your assignment