import numpy as np
import math

# Define the texture image matrix from the given image data
texture_image = np.array([
    [3, 5, 1, 8, 1, 3, 3, 2, 1, 1, 1, 2, 4],
    [1, 5, 5, 2, 5, 3, 3, 4, 5, 0, 5, 6, 1],
    [4, 3, 4, 1, 2, 7, 2, 4, 2, 7, 4, 5, 0],
    [0, 8, 2, 4, 3, 1, 3, 7, 5, 3, 2, 9, 7],
    [5, 3, 7, 7, 5, 3, 2, 1, 7, 2, 7, 2, 3],
    [0, 0, 2, 5, 1, 4, 2, 1, 3, 0, 2, 1, 2],
    [7, 3, 3, 0, 0, 3, 0, 0, 0, 1, 3, 0, 0],
    [4, 8, 2, 3, 7, 0, 3, 0, 7, 4, 2, 1, 1],
    [1, 4, 5, 8, 1, 1, 7, 2, 1, 3, 5, 2, 4],
    [1, 6, 5, 6, 3, 4, 3, 5, 5, 4, 5, 7, 3],
    [1, 7, 5, 9, 3, 6, 3, 6, 3, 4, 5, 7, 4],
    [4, 2, 4, 8, 0, 5, 4, 2, 0, 1, 4, 2, 4],
    [0, 2, 0, 3, 7, 5, 2, 0, 7, 3, 0, 1, 1]
])

def compute_glcm(matrix, dx, dy):
    max_value = np.max(matrix)
    glcm = np.zeros((max_value + 1, max_value + 1), dtype=int)

    rows, cols = matrix.shape
    for i in range(rows):
        for j in range(cols):
            if i + dy < rows and j + dx < cols:
                glcm[matrix[i, j], matrix[i + dy, j + dx]] += 1

    return glcm

def miux(glcm):
    tot = 0
    for i in range(glcm.shape[0]):
        sum = 0
        for j in range(glcm.shape[1]):
            sum += glcm[i, j]
        tot += sum * i
    return tot

def miuy(glcm):
    tot = 0
    for j in range(glcm.shape[1]):
        sum = 0
        for i in range(glcm.shape[0]):
            sum += glcm[i, j]
        tot += j * sum
    return tot

def sigmax(ux, glcm):
    tot = 0
    for i in range(glcm.shape[0]):
        sum = 0
        for j in range(glcm.shape[1]):
            sum += glcm[i, j]
        tot += sum * (i - ux) * (i - ux)
    return math.sqrt(tot)

def sigmay(uy, glcm):
    tot = 0
    for j in range(glcm.shape[1]):
        sum = 0
        for i in range(glcm.shape[0]):
            sum += glcm[i, j]
        tot += (j - uy) * (j - uy) * sum
    return math.sqrt(tot)

def correlation(glcm):
    ux = miux(glcm)
    uy = miuy(glcm)
    ox = sigmax(ux, glcm)
    oy = sigmay(uy, glcm)
    tot = 0
    for i in range(glcm.shape[0]):
        for j in range(glcm.shape[1]):
            tot += (i - ux) * (j - uy) * glcm[i, j]
    return tot / (ox * oy)

def sum_entropy(glcm):
    mx = glcm.shape[0]
    freq = np.zeros(2 * (mx + 1), dtype=int)
    for i in range(glcm.shape[0]):
        for j in range(glcm.shape[1]):
            freq[i + j] += glcm[i, j]
    ans = 0
    for i in range(2 * (mx + 1)):
        if freq[i] == 0:
            continue
        ans += freq[i] * math.log(freq[i])
    return -ans

def difference_entropy(glcm):
    mx = glcm.shape[0]
    freq = np.zeros(2 * (mx + 1), dtype=int)
    for i in range(glcm.shape[0]):
        for j in range(glcm.shape[1]):
            freq[int(math.fabs(i - j))] += glcm[i, j]
    ans = 0
    for i in range(2 * (mx + 1)):
        if freq[i] == 0:
            continue
        ans += freq[i] * math.log(freq[i])
    return -ans

# Compute the GLCM for distance (2, 2)
glcm = compute_glcm(texture_image, 2, 2)
print(glcm)

asm = np.sum(glcm ** 2)
corr = correlation(glcm)
sent = sum_entropy(glcm)
dent = difference_entropy(glcm)

print(f'''
    asm = {asm}
    correlation = {corr}
    sent = {sent}
    dent = {dent}
''')


[3, 5, 1, 8, 1, 3, 3, 2, 1, 1, 1, 2, 4],
        [1, 5, 5, 2, 5, 3, 3, 4, 5, 0, 5, 6, 1],
        [4, 3, 4, 1, 2, 7, 2, 4, 2, 7, 4, 5, 0],
        [0, 8, 2, 4, 3, 1, 3, 7, 5, 3, 2, 9, 7],
        [5, 3, 7, 7, 5, 3, 2, 1, 7, 2, 7, 2, 3],
        [0, 0, 2, 5, 1, 4, 2, 1, 3, 0, 2, 1, 2],
        [7, 3, 3, 0, 0, 3, 0, 0, 0, 1, 3, 0, 0],
        [4, 8, 2, 3, 7, 0, 3, 0, 7, 4, 2, 1, 1],
        [1, 4, 5, 8, 1, 1, 7, 2, 1, 3, 5, 2, 4],
        [1, 6, 5, 6, 3, 4, 3, 5, 5, 4, 5, 7, 3],
        [1, 7, 5, 9, 3, 6, 3, 6, 3, 4, 5, 7, 4],
        [4, 2, 4, 8, 0, 5, 4, 2, 0, 1, 4, 2, 4],
        [0, 2, 0, 3, 7, 5, 2, 0, 7, 3, 0, 1, 1]