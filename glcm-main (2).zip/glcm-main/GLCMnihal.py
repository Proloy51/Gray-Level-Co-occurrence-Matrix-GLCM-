data = [
    [3, 5, 1, 8, 1, 3, 3, 2, 1, 1, 1, 2, 4],
    [1, 5, 5, 2, 5, 3, 3, 4, 5, 0, 5, 6, 1],
    [4, 3, 4, 1, 2, 7, 2, 4, 2, 7, 4, 5, 0],
    [0, 8, 2, 4, 3, 1, 3, 7, 5, 3, 2, 9, 7],
    [5, 3, 7, 7, 5, 3, 2, 1, 7, 2, 7, 2, 3],
    [0, 0, 2, 5, 1, 4, 2, 1, 3, 0, 2, 1, 2],
    [7, 3, 3, 0, 0, 3, 0, 0, 0, 1, 3, 0, 0],
    [4, 8, 2, 3, 7, 0, 3, 0, 7, 4, 2, 1, 1],
    [1, 4, 5, 8, 1, 1, 7, 2, 1, 3, 5, 2, 4],
    [1, 6, 5, 6, 3, 4, 3, 5, 5, 4, 5, 7, 3],
    [1, 7, 5, 9, 3, 6, 3, 6, 3, 4, 5, 7, 4],
    [4, 2, 4, 8, 0, 5, 4, 2, 0, 1, 4, 2, 4],
    [0, 2, 0, 3, 7, 5, 2, 0, 7, 3, 0, 1, 1]
]

glcm = [[0 for _ in range(10)] for _ in range(10)]

dx = 0
dy = -1

for i in range(13):
    for j in range(13):
        if j+dy >= 0 and j+dy < 13 and i+dx >= 0 and i+dx < 13:
            glcm[data[j][i]][data[j+dy][i+dx]] += 1

for i in glcm:
    print(i)

tot = 0
for i in range(10):
    for j in range(10):
        tot += glcm[i][j]

print(tot)

prob = [[0 for _ in range(10)] for _ in range(10)]

for i in range(10):
    for j in range(10):
        prob[i][j] = glcm[i][j] / tot

for i in prob:
    print(i)

mr = 0
for i in range(10):
    sum2 = 0
    for j in range(10):
        sum2 += prob[i][j]
    mr += (i+1) * sum2

varr = 0
for i in range(10):
    sum2 = 0
    for j in range(10):
        sum2 += prob[i][j]
    varr += (i+1 - mr) ** 2 * sum2

mc = 0
for j in range(10):
    sum2 = 0
    for i in range(10):
        sum2 += prob[i][j]
    mc += (j+1) * sum2

varc = 0
for j in range(10):
    sum2 = 0
    for i in range(10):
        sum2 += prob[i][j]
    varc += (j+1 - mc) ** 2 * sum2

print(mr, mc, varr, varc)

angular_second_moment = 0
for i in range(10):
    sum2 = 0
    for j in range(10):
        sum2 += prob[i][j] ** 2
    angular_second_moment += sum2
print(angular_second_moment)

inverse_difference_moment = 0
for i in range(10):
    for j in range(10):
        sum2 += (1 / (1 + ((i+1) - (j+1)) ** 2)) * prob[i][j]
    inverse_difference_moment += sum2
print(inverse_difference_moment)

import math

entropy = 0
for i in range(10):
    for j in range(10):
        if (prob[i][j] > 0):
            sum2 += prob[i][j] * math.log(prob[i][j])
    entropy += sum2

entropy = -entropy
print(entropy)

hxy = 0
for i in range(10):
    for j in range(10):
        if (prob[i][j] > 0):
            sum2 += prob[i][j] * math.log(prob[i][j])
    hxy += sum2
hxy = -hxy

px = []
for i in range(10):
    sum2 = 0
    for j in range(10):
        sum2 += prob[i][j]
    px.append(sum2)

py = []
for j in range(10):
    sum2 = 0
    for i in range(10):
        sum2 += prob[i][j]
    py.append(sum2)

hx = 0
for i in range(10):
    if (px[i] > 0):
        hx += px[i] * math.log(px[i])
hx = -hx

hy = 0
for j in range(10):
    if (py[j] > 0):
        hy += py[j] * math.log(py[j])
hy = -hy

hxy1 = 0
for i in range(10):
    sum2 = 0
    for j in range(10):
        if (prob[i][j] > 0):
            sum2 += prob[i][j] * math.log(px[i] * py[j])
    hxy1 += sum2
hxy1 = -hxy1

hxy2 = 0
for i in range(10):
    sum2 = 0
    for j in range(10):
        if (px[i] > 0 and py[j] > 0):
            sum2 += px[i] * py[j] * math.log(px[i] * py[j])
    hxy2 += sum2
hxy2 = -hxy1

f12 = (hxy - hxy1) / max(hx, hy)
print(f12)

f13 = (1 - math.exp(-2.0 * (hxy2 - hxy))) ** 0.5
print(f13)








